package lab_05group9;

public interface TransactionLogger {
	default void logTransaction(String message) {	// Stores transaction history
		
	}

}
