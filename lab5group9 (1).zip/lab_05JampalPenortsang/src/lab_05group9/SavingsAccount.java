package lab_05group9;

public class SavingsAccount extends BankAccount {
    public SavingsAccount(int accountNumber, String holderName, double initialDeposit) {
        super(accountNumber, holderName, initialDeposit);
    }

    public void checkMinimumBalance() {
        if (getBalance() < 100) {
            System.out.println("Insufficient funds!");
            logTransaction("User went under minimum balance.");
        }
    }

    public void logTransaction(String message) {
        System.out.println(message);
    }

    public void applyInterest(boolean month) {
        if (month) {
            double interest = balance * 0.05;
            deposit(interest);
            logTransaction("User accrued 5% interest after a month.");
        }
    }

    public double getBalance() {
        return balance;
    }
}
