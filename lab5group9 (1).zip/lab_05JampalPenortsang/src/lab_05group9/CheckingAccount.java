package lab_05group9;

public class CheckingAccount extends BankAccount {

    public CheckingAccount(int accountNumber, String holderName, double initialDeposit) {
        super(accountNumber, holderName, initialDeposit);
    }

    public void overdraft(double amount) {
        if (amount > 0 && amount < 500) {
            balance += amount;
            balance -= 100;
            System.out.println("Overdraft: " + amount + " + $100 overdraft fee.");
            logTransaction("User applied for an overdraft of " + amount + " and was charged an additional $100 for the overdraft fee.");
        } else {
            System.out.println("Invalid amount.");
        }
    }
    public void logTransaction(String message) {
        System.out.println(message);
    }
}
