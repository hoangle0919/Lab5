package lab_05group9;

import java.util.ArrayList;
import java.util.Scanner;

public class Bank {
    private ArrayList<BankAccount> accounts; // List to hold bank accounts
    private int accountCounter; // Counter for account numbers

    public Bank() {
        accounts = new ArrayList<>(); // Initialize the accounts list
        accountCounter = 1; // Start account numbers from 1
    }

    // Create a new bank account
    public void createAccount(String holderName, double initialDeposit) {
        BankAccount account = new BankAccount(accountCounter, holderName, initialDeposit);
        accounts.add(account);
        System.out.println("Account created successfully. Account Number: " + accountCounter);
        accountCounter++; // Increment account number for next account
    }

    // Deposit money into an account
    public void deposit(int accountNumber, double amount) {
        for (BankAccount account : accounts) {
            if (account.getAccountNumber() == accountNumber) {
                account.deposit(amount);
                return;
            }
        }
        System.out.println("Account not found.");
    }

    // Withdraw money from an account
    public void withdraw(int accountNumber, double amount) {
        for (BankAccount account : accounts) {
            if (account.getAccountNumber() == accountNumber) {
                account.withdraw(amount);
                return;
            }
        }
        System.out.println("Account not found.");
    }

    // Display all accounts
    public void displayAccounts() {
        for (BankAccount account : accounts) {
            account.displayAccountInfo();
            System.out.println("-----------------------");
        }
    }

    public static void main(String[] args) {
        Bank bank = new Bank();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Create Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Display All Accounts");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter holder name: ");
                    String name = scanner.next();
                    System.out.print("Enter initial deposit: ");
                    double deposit = scanner.nextDouble();
                    bank.createAccount(name, deposit);
                    break;
                case 2:
                    System.out.print("Enter account number: ");
                    int depositAcc = scanner.nextInt();
                    System.out.print("Enter amount to deposit: ");
                    double depositAmount = scanner.nextDouble();
                    bank.deposit(depositAcc, depositAmount);
                    break;
                case 3:
                    System.out.print("Enter account number: ");
                    int withdrawAcc = scanner.nextInt();
                    System.out.print("Enter amount to withdraw: ");
                    double withdrawAmount = scanner.nextDouble();
                    bank.withdraw(withdrawAcc, withdrawAmount);
                    break;
                case 4:
                    bank.displayAccounts();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
